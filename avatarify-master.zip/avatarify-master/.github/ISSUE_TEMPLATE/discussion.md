---
name: Discussion
about: Discuss a new feature or improvement.
title: ''
labels: ''
assignees: ''

---

<!-- Please don't use this form if you want to ask something. You are welcome to join our Slack community and ask your question in the ask or ask_install channels. -->
